from django.contrib import admin
from .models import Apoio, OndeFicar
# Register your models here.

admin.site.register(OndeFicar)
admin.site.register(Apoio)